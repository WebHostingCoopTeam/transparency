#!/bin/bash
cd hostbill
perl mkhostbillforLedger.pl
